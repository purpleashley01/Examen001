package examen01;
import java.util.Scanner;
public class main_menu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado=new Scanner(System.in);
		
		int password=12345,password_1;
		String user="Martha", name=user;
		int count=1,op=0,reg=0,ingresar;
		boolean exit=true;
		
		
		System.out.println("Ingrese su nombre:");
		name=teclado.nextLine();
		
		while(user!=name||password!=123||count<=3) {
			System.out.println("ingrese su nombre:");
			name=teclado.nextLine();
			System.out.println("Ingrese la contraseña:");
			password=teclado.nextInt();
			if(user.equals(user) && password==12345) {
				System.out.println("Ha ingresado al sistema!"+"\n Bienvenido!!");
				break;
			}
			else if(count>=3) {
				System.out.println("Ha agotado sus intentos!:(");
				break;
			}
			count++;
		}
		System.out.println("Menu de opciones:");
		op=teclado.nextInt();
		System.out.println("*****************");
		System.out.println("1.Camisa");
		System.out.println("2.Pantalón");
		System.out.println("3.Zapatos");
		System.out.println("4.Cartera");
		System.out.println("5.Bolso");
		
		System.out.println("Eliga una opcion de 0 al 6");
		ingresar=teclado.nextInt();
		
		switch(op) { 
		case 0:
		System.out.println(" Ha ingresado al menu");
		break;
		case 1:
			System.out.println("camisa $10");
			break;
		case 2:
			System.out.println("Pantalón $15");
		break;
		case 3:
			System.out.println("Zapatos $35");
			break;
		case 4:
			System.out.println("Cartera $27");
			break;
		case 5:
			System.out.println("Bolso $45");
			break;
		case 6:
			System.out.println("Salida:");
			System.out.println("Usted ha salido del menu de opciones");
			break;
		}
		
		System.out.println("Ha ingresao a caja");
		System.out.println("¡Que desee registrar en el carrito de compras?:");
		reg=teclado.nextInt();
		int compras;
	System.out.println("*************Factura***********");
	teclado.nextLine();
	System.out.println("\nNombre del comprador:"+name);
	System.out.println("Nombre del producto y precio:"+ingresar);
	System.out.println("\n Tipo de pago:"+"efectivo");
	System.out.println("\nNombre de la tienda"+"** La nueva**");
	System.out.println("¡Gracias por su compra:");
	
	System.out.println("DEsea salir?");
if(exit=true) {
	System.out.println("Usted ha salido del sistema! ");
	
}
	
	
	
	}

}
