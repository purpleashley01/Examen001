package examen01;
import java.util.Scanner;
public class main_insercion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado=new Scanner(System.in);
		
		double  n;
		System.out.println("Ingrese una cantidad de numeros:");
		n=teclado.nextInt();
		
		float nums[]=new float[(int)n];
		for(int i=0;i<n;i++) {
		System.out.println("Ingrese un numero en la posicion:"+(i+1));
		nums[i]=teclado.nextInt();
		}
		
		for(int i=0;i<n;i++) {
			int pos=i;
			float aux=nums[i];
			while((pos>0)&&(nums[pos-1]>aux)) {
				nums[pos]=nums[pos-1];
				pos--;
			}
			nums[pos]=aux;
			
		}
		System.out.println("Orden ascendente:");
		for(int i=0;i<n;i++) {
			System.out.println(nums[i]+"-");
		}
		
		
		
	}

}
